'use client';

import ExpertConnectPage from '@/components/ExpertConnectPage';

export default function ExpertConnect() {
  return <ExpertConnectPage />;
}