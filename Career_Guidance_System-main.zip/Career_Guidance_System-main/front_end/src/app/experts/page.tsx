'use client';
import React from 'react';
import ExpertConnectPage from '@/pages/ExpertConnectPage';

export default function ExpertsPage() {
  return <ExpertConnectPage />;
}